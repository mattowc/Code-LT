<div id="sidebar" >
                  	
            <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar(6) )  ?>        
                    
 	 

</div><!-- sidebar #end -->